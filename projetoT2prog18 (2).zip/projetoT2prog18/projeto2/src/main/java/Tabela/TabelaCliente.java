/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tabela;

import Modelo.Cliente;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author User
 */
public class TabelaCliente extends AbstractTableModel {
    
    private List<Cliente> clientes;
    private String[] nomeColunas = {"Nome", "CPF", "Plano"};

    private final int COLUNA_NOME = 0;
    private final int COLUNA_CPF = 1;
    private final int COLUNA_PLANO = 2;
  

    public TabelaCliente(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    @Override
    public int getRowCount() {
        return clientes.size();
    }

    @Override
    public int getColumnCount() {
        return nomeColunas.length;
    }

    @Override
    public String getColumnName (int column){
        return nomeColunas[column];
    }

    public void atualizar() {
        this.fireTableDataChanged();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Cliente cliente = clientes.get(rowIndex);
        String valor = null;
        switch(columnIndex){
            case COLUNA_NOME:
                valor = cliente.getNome();
                break;
            case COLUNA_CPF:
                valor = cliente.getCPF();
                break;
            case COLUNA_PLANO:
                valor = cliente.getPlano();
                break;
            
        }

        return valor;
    }

    public void addRow(Cliente clie){
        this.clientes.add(clie);
        this.fireTableDataChanged();
    }

    public List<Cliente> getCliente() {
        return clientes;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {

    	Cliente cliente = this.clientes.get(rowIndex);

        switch (columnIndex) {
            case COLUNA_NOME:
                cliente.setNome((String) aValue);
                break;
            case COLUNA_CPF:
                cliente.setCPF((String) aValue);
                break;
            case COLUNA_PLANO:
                cliente.setPlano((String) aValue);
                break;
           
        }
        //este método é que notifica a tabela que houve alteração de dados
        fireTableDataChanged();
    }

    public void setCargos(List<Cliente> clientes) {
        this.clientes = clientes;
    }
}
