/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tabela;



import Modelo.Plano;
import java.util.List;
import javax.swing.table.AbstractTableModel;


public class TabelaPlano extends AbstractTableModel {
    private List<Plano> planos;
    private String[] nomeColunas = {"Nome", "Preço"};

    private final int COLUNA_NOME = 0;
    private final int COLUNA_PREÇO = 1;
    
  

    public TabelaPlano(List<Plano> planos) {
        this.planos = planos;
    }

    @Override
    public int getRowCount() {
        return planos.size();
    }

    @Override
    public int getColumnCount() {
        return nomeColunas.length;
    }

    @Override
    public String getColumnName (int column){
        return nomeColunas[column];
    }

    public void atualizar() {
        this.fireTableDataChanged();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Plano plano = planos.get(rowIndex);
        String valor = null;
        switch(columnIndex){
            case COLUNA_NOME:
                valor = plano.getNome();
                break;
            case COLUNA_PREÇO:
                valor = plano.getPreco();
                break;
           
            
        }

        return valor;
    }

    public void addRow(Plano plan){
        this.planos.add(plan);
        this.fireTableDataChanged();
    }

    public List<Plano> getPlano() {
        return planos;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {

    	Plano plano = this.planos.get(rowIndex);

        switch (columnIndex) {
            case COLUNA_NOME:
                plano.setNome((String) aValue);
                break;
            case COLUNA_PREÇO:
                plano.setPreco((String) aValue);
                break;
            
           
        }
        //este método é que notifica a tabela que houve alteração de dados
        fireTableDataChanged();
    }

    public void setPlano(List<Plano> planos) {
        this.planos = planos;
    }
}


