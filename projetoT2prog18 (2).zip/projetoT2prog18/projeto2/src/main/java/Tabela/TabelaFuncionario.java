/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tabela;

import Modelo.Funcionario;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author User
 */
public class TabelaFuncionario extends AbstractTableModel {
    
    
    private List<Funcionario> funcionarios;
    private String[] nomeColunas = {"Nome", "CPF", "Cargo"};

    private final int COLUNA_NOME = 0;
    private final int COLUNA_CPF = 1;
    private final int COLUNA_CARGO = 2;
  

    public TabelaFuncionario(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }

    @Override
    public int getRowCount() {
        return funcionarios.size();
    }

    @Override
    public int getColumnCount() {
        return nomeColunas.length;
    }

    @Override
    public String getColumnName (int column){
        return nomeColunas[column];
    }

    public void atualizar() {
        this.fireTableDataChanged();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Funcionario funcionario = funcionarios.get(rowIndex);
        String valor = null;
        switch(columnIndex){
            case COLUNA_NOME:
                valor = funcionario.getNome();
                break;
            case COLUNA_CPF:
                valor = funcionario.getCPF();
                break;
            case COLUNA_CARGO:
                valor = funcionario.getPIS();
                break;
            
        }

        return valor;
    }

    public void addRow(Funcionario fun){
        this.funcionarios.add(fun);
        this.fireTableDataChanged();
    }

    public List<Funcionario> getFuncionario() {
        return funcionarios;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {

    	Funcionario funcionario = this.funcionarios.get(rowIndex);

        switch (columnIndex) {
            case COLUNA_NOME:
                funcionario.setNome((String) aValue);
                break;
            case COLUNA_CPF:
                funcionario.setCPF((String) aValue);
                break;
            case COLUNA_CARGO:
                funcionario.setPIS((String) aValue);
                break;
           
        }
        //este método é que notifica a tabela que houve alteração de dados
        fireTableDataChanged();
    }

    public void setFuncionario(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }
}

