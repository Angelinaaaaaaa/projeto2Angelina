/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Cliente;
import Modelo.DAO.DAOCliente;
import Visao.ViewBuscarCliente;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class ControladorBuscarCliente {
    private ViewBuscarCliente telaBusca;
    private DAOCliente daoCliente;
    
    public ControladorBuscarCliente(){
        telaBusca= new ViewBuscarCliente();
        inicializarAcaoBotoesMenu();        
    }

public void exibirTela(){
     telaBusca.exibirTela();
}
    private void inicializarAcaoBotoesMenu() {
        telaBusca.adicionarAcaoBuscar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscaPorNome(telaBusca.getNome());
            }
        });
        
        telaBusca.adicionarAcaoVoltar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorTelaPrincipal cont = new ControladorTelaPrincipal();
                cont.exibirTela();

                telaBusca.setVisible(false); 
            }
        });

    }

    public Cliente buscaPorNome(String nome){
        int cont = 0;
        Iterator<Cliente> it = daoCliente.getCliente().iterator(); 
		while(it.hasNext()){ 
                    Cliente salva =it.next();
                    if(salva.getNome().equalsIgnoreCase(nome)){
                         cont = 1+cont;
                        JOptionPane.showMessageDialog(null, salva.toString());
                    }
                    if(cont == 0){
                        JOptionPane.showMessageDialog(null, "Confira se o nome do cliente foi digitado corretamente!");
                    }
		}
        return null;
    }
}
