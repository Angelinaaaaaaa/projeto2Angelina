/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Cliente;
import Modelo.DAO.DAOCliente;
import Tabela.TabelaCliente;
import Visao.ViewCadastraCliente;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class ControladorCadastroClientes {
    
    private ViewCadastraCliente telaCliente;
    private Cliente cliente;
    private TabelaCliente clienteTabela;
    private DAOCliente clienteDAO;
    
    public ControladorCadastroClientes() {
         telaCliente = new ViewCadastraCliente();
         clienteTabela = new TabelaCliente(clienteDAO.getCliente());
        setTableModelCliente();
        inicializarAcaoBotoesMenu();
    
    }
    
    private void setTableModelCliente(){
        telaCliente.setTableModelCliente(this.clienteTabela);
    }
    
    public void exibirTela() {
        telaCliente.exibirTela();
    }

    private void inicializarAcaoBotoesMenu() {
        telaCliente.adicionarAcaoSalvar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cadastra();
            }
        });
        
        telaCliente.adicionarAcaoExcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Excluir();
            }
        });
        
        telaCliente.adicionarAcaoVoltar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorTelaPrincipal cont = new ControladorTelaPrincipal();
                cont.exibirTela();

                telaCliente.setVisible(false); 
            }
        });

    }

    public void Excluir(){
        if (telaCliente.getLinhaCliente()== -1){
            telaCliente.exibirMensagem("Nenhum cargo selecionado!");
        } else {
             String CPF = telaCliente.getCpfClienteSelecionado();

            if (DAOCliente.excluirCliente(CPF)){
                telaCliente.exibirMensagem("Cliente excluido com sucesso");
               clienteTabela.atualizar();
            }
             else {
                telaCliente.exibirMensagem("Não foi possível Excluir o Cliente");
            }
        }
    }
    
    public void Cadastra(){
        
        if (validarCliente()) {
            cliente = new Cliente( telaCliente.getNome(), telaCliente.getCPF(), telaCliente.getPlano());
            if(DAOCliente.salvarCliente(cliente)){
                telaCliente.exibirMensagem("Cliente cadastrado com sucesso. ");
                telaCliente.LimpaTela();
                clienteTabela.atualizar();
            }
        }
        else {
            telaCliente.exibirMensagem("Algum campo esta em branco ou preenchido incorretamente! ");
        }
   
    }

    private boolean validarCliente() {
        if (this.telaCliente.getNome().equals(""))  
            return false;
    
        if (this.telaCliente.getCPF().equals(""))
            return false;
        
        if (this.telaCliente.getPlano().equals(""))
            return false;
       
        return true;
    }
    
}
