/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.DAO.DAOFuncionario;
import Modelo.Funcionario;
import Tabela.TabelaFuncionario;
import Visao.ViewCadastraFuncionario;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author User
 */
public class ControladorCadastroFuncionario {
    private ViewCadastraFuncionario telaFuncionario;
    private Funcionario funcionario;
     private TabelaFuncionario funcionarioTabela;
    private DAOFuncionario funcionarioDAO;
    
    public ControladorCadastroFuncionario() {
         telaFuncionario = new ViewCadastraFuncionario();
         funcionarioTabela = new TabelaFuncionario(funcionarioDAO.getFuncionario());
         setTableModelFuncionario();
        inicializarAcaoBotoesMenu();
    
    }
    
     private void setTableModelFuncionario(){
        telaFuncionario.setTableModelFuncionario(this.funcionarioTabela);
    }
    
    public void exibirTela() {
        telaFuncionario.exibirTela();
    }

    private void inicializarAcaoBotoesMenu() {
        telaFuncionario.adicionarAcaoSalvar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cadastra();
            }
        });
        
        telaFuncionario.adicionarAcaoExcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Excluir();
            }
        });
        
        telaFuncionario.adicionarAcaoVoltar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorTelaPrincipal cont = new ControladorTelaPrincipal();
                cont.exibirTela();

                telaFuncionario.setVisible(false);
            }
        });

    }

    public void Excluir(){
            if (telaFuncionario.getLinhaFuncionario()== -1){
                telaFuncionario.exibirMensagem("Nenhum cargo selecionado!");
            } else {
                String cpf = telaFuncionario.getCpfFuncionarioSelecionado();

                if (DAOFuncionario.excluirFuncionario(cpf)){
                    telaFuncionario.exibirMensagem("Funcionario excluido com sucesso");
                    funcionarioTabela.atualizar();
                }
                else {
                    telaFuncionario.exibirMensagem("Não foi possível Excluir o funcionario");
                }
            }
        }
    
    public void Cadastra(){
        
        if (validarFuncionario()) {
            funcionario = new Funcionario( telaFuncionario.getNome(), telaFuncionario.getCPF(), telaFuncionario.getCargo());
            if(DAOFuncionario.salvarFuncionario(funcionario)){
                telaFuncionario.exibirMensagem("Funcionario cadastrado com sucesso. ");
                telaFuncionario.LimpaTela();
                funcionarioTabela.atualizar();
            }
        }
        else {
            telaFuncionario.exibirMensagem("Algum campo esta em branco ou preenchido incorretamente! ");
        }
   
    }

    private boolean validarFuncionario() {
        if (this.telaFuncionario.getNome().equals(""))  
            return false;
    
        if (this.telaFuncionario.getCPF().equals(""))
            return false;
        
        if (this.telaFuncionario.getCargo().equals(""))
            return false;
       
        return true;
    }
    
}
