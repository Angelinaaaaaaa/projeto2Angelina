
package Controlador;

import Modelo.DAO.DAOPlano;
import Modelo.Plano;
import Tabela.TabelaPlano;
import Visao.ViewCadastraPlano;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorCadastroPlano {
    private ViewCadastraPlano telaplano;
    private Plano plano;
    private TabelaPlano planoTabela;
    private DAOPlano planoDAO;

    public ControladorCadastroPlano() {
         telaplano = new ViewCadastraPlano();
         planoTabela = new TabelaPlano(planoDAO.getPlano());
         setTableModelPlano();
        inicializarAcaoBotoesMenu();
    
    }
    
     private void setTableModelPlano(){
        telaplano.setTableModelPlano(this.planoTabela);
    }
    
    public void exibirTela() {
        telaplano.exibirTela();
    }

    private void inicializarAcaoBotoesMenu() {
        telaplano.adicionarAcaoSalvar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cadastra();
            }
        });
        
        telaplano.adicionarAcaoExcluir(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Excluir();
            }
        });
        
        telaplano.adicionarAcaoVoltar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorTelaPrincipal cont = new ControladorTelaPrincipal();
                cont.exibirTela();

                telaplano.setVisible(false);
            }
        });

    }

     public void Excluir(){
            if (telaplano.getLinhaPlano()== -1){
                telaplano.exibirMensagem("Nenhum cargo selecionado!");
            } else {
                String cargo = telaplano.getNomePlanoSelecionado();

                if (DAOPlano.excluirPlano(cargo)){
                    telaplano.exibirMensagem("Plano excluido com sucesso");
                   planoTabela.atualizar();
                }
                else {
                    telaplano.exibirMensagem("Não foi possível Excluir o plano");
                }
            }
        }
     
    public void Cadastra(){
        
        if (validarCliente()) {
            plano = new Plano( telaplano.getNome(), telaplano.getPreco());
            if(DAOPlano.salvarPlano(plano)){
                telaplano.exibirMensagem("Plano cadastrado com sucesso. ");
                telaplano.LimpaTela();
                planoTabela.atualizar();
            }
        }
        else {
            telaplano.exibirMensagem("Algum campo esta em branco ou preenchido incorretamente! ");
        }
   
    }

    private boolean validarCliente() {
        if (this.telaplano.getNome().equals(""))  
            return false;
    
        if (this.telaplano.getPreco().equals(""))
            return false;
        
       
        return true;
    }
    
}
